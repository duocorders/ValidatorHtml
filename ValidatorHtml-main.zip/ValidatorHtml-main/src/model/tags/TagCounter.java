package model.tags;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TagCounter {
    private final List<TagInfo> tags = new ArrayList<>();

    public void add(String tag) {
        tag = tag.toLowerCase();
        for (TagInfo tagInfo : tags) {
            if (tagInfo.getName().equals(tag)) {
                tagInfo.increment();
                return;
            }
        }
        tags.add(new TagInfo(tag));
    }

    public TagInfo[] getSortedTags() {
        List<TagInfo> sorted = new ArrayList<>(tags);
        Collections.sort(sorted, Comparator.comparing(TagInfo::getName));
        return sorted.toArray(new TagInfo[0]);
    }
}