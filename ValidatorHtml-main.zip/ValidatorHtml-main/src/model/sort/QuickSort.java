package model.sort;

public class QuickSort<T extends Comparable<T>> extends AbstractSort<T> {

    @Override
    public void sort() {
        quickSort(0, getData().length - 1);
    }

    private void quickSort(int inicio, int fim) {
        if (inicio < fim) {
            int pivo = particionar(inicio, fim);
            quickSort(inicio, pivo - 1);
            quickSort(pivo + 1, fim);
        }
    }

    private int particionar(int inicio, int fim) {
        T[] vetor = getData();
        T pivo = vetor[inicio];
        int a = inicio + 1;
        int b = fim;

        while (true) {
            while (a <= fim && vetor[a].compareTo(pivo) <= 0) {
                a++;
            }
            while (b >= inicio && vetor[b].compareTo(pivo) > 0) {
                b--;
            }
            if (a >= b) {
                break;
            }
            swap(a, b);
        }

        swap(inicio, b);
        return b;
    }
}
